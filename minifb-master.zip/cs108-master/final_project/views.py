from django.shortcuts import render
from django.views.generic import ListView, DetailView
from .models import Event, Category
from .forms import CreateEventForm, UpdateEventForm
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse # to obtain a url from pattern name 


class ShowAllEventsView(ListView):
    '''Create a subclass of ListView to display all events'''

    model = Event # retrieve objects of type Event from the database
    template_name = 'events/show_all_events.html'
    context_object_name = 'all_events_list' # how to find the data in the template file
    ordering = ['date']



class ShowAllCategoriesView(ListView):
    '''Create a subclass of Listview to display all categories'''

    model = Category # retrieve objects of type Category from the database
    template_name = 'events/show_all_categories.html'
    context_object_name = 'all_categories_list'
    


class EventPageView(DetailView):
    '''Shows the details for one event'''

    model = Event # retrieve objects of type Event from the database
    template_name = 'events/event_page.html'
    context_object_name = 'event_page'



class CategoryPageView(DetailView):
    '''Show all events under a specific category'''

    model = Category # retrieve objects of type Category from the database
    template_name = 'events/category.html'
    context_object_name = 'category'
    ordering = ['date']

    

class CreateEventView(CreateView):
    '''Allows user to create a new event and save it to the database'''

    form_class = CreateEventForm 
    template_name = 'events/create_event.html'
    content_object_name = 'create_event'



class UpdateEventView(UpdateView):
    '''Allows user to update an event and save it to the database'''

    form_class = UpdateEventForm
    template_name = 'events/update_event.html'
    queryset = Event.objects.all()



class DeleteEventView(DeleteView):
    '''Allows user to update an event and save it to the database'''

    template_name = 'events/delete_event.html'
    queryset = Event.objects.all() 
    success_url = "../../" # redirects user to home page upon deletion 

