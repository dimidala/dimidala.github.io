from django.db import models
from django.urls import reverse # to obtain a url from pattern name 


# Create your models here.
class Event(models.Model):
    '''Encapsulate the idea of an event'''

    # data attributes of an event
    name = models.TextField(blank=True)
    description = models.TextField(blank=True)
    date = models.DateField(blank=True)
    venue = models.TextField(blank=True)
    ticket_price = models.TextField(blank=True)
    image_url = models.URLField(blank=True)
    category = models.ForeignKey('Category', on_delete="CASCADE")


    def __str__(self):
        '''Return a string representaion of this Event.'''
        return '%s %s %s %s %s %s %s' % (self.name, self.description, self.date, self.venue, self.ticket_price, self.image_url, self.category)
    

    def get_absolute_url(self):
        '''Return a URL to display this Event.'''
        return reverse("event_page", kwargs={"pk": self.pk})



class Category(models.Model):
    '''Encapsulate the idea of an event category'''

    event_type = models.TextField(blank=True)


    def __str__(self):
        '''Return a string representation of this Category'''
        return self.event_type


    # redirects you to category page
    def get_absolute_url(self):
        '''Return a URL to display this Category.'''
        return reverse("category", kwargs={"pk": self.pk})


    # get all events for a category
    def get_all_events(self):
        '''return a Queryset of all events under this category'''

        events = Event.objects.filter(category=self.pk)
        return events

    