from django.apps import AppConfig


class FinalProjectConfig(AppConfig):
    name = 'final_project'
