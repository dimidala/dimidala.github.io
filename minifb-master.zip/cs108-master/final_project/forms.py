from django import forms
from .models import Event

class CreateEventForm(forms.ModelForm):
    '''Form to add new events to the database'''

    class Meta:
        model = Event 
        fields = ['name', 'description', 'date', 'venue', 'ticket_price', 'image_url', 'category', ] # which fields the model should use to create an event


class UpdateEventForm(forms.ModelForm):
    '''Form to allow any updates of an event'''

    class Meta:
        model = Event
        fields = ['name', 'description', 'date', 'venue', 'ticket_price', 'image_url', 'category', ] # fields the model should use to update an event