# final_project.urls.py

from django.urls import path
from .views import *

urlpatterns = [
    # map the URL (empty string) to the view 
    
    path('', ShowAllEventsView.as_view(), name='show_all_events'), # generic class-based view

    path('all_categories', ShowAllCategoriesView.as_view(), name='show_all_categories'), # generic class-based view

    path('event/<int:pk>', EventPageView.as_view(), name='event_page'), # show one event

    path('category/<int:pk>', CategoryPageView.as_view(), name='category'), # show events under a specific category

    path('create_event', CreateEventView.as_view(), name='create_event'), # create an event

    path('event/<int:pk>/update', UpdateEventView.as_view(), name='update_event'), # update an event

    path('event/<int:pk>/delete', DeleteEventView.as_view(), name='delete_event'), # delete an event

]

