from django.db import models
from django.urls import reverse # to obtain a url from pattern name 

# Create your models here.
class Profile(models.Model):
    
    first_name = models.TextField(blank=True)
    last_name = models.TextField(blank=True)
    city = models.TextField(blank=True)
    email = models.TextField(blank=True)
    image_url = models.URLField(blank=True)

    def __str__(self):
        '''Return a string representaion of this object.'''
        return '%s %s %s %s %s' % (self.first_name, self.last_name, self.city, self.email, self.image_url)

    def get_status_messages(self):
        status = StatusMessage.objects.filter(profile=self.pk)
        return status 

    def get_absolute_url(self):
        '''Return a URL to display this profile object.'''
        return reverse("show_event_page", kwargs={"pk": self.pk})
        

class StatusMessage(models.Model):

    timestamp = models.DateTimeField(auto_now_add=True)
    message = models.TextField(blank=True)
    profile = models.ForeignKey('Profile', on_delete="CASCADE")
    image = models.ImageField(blank=True)

    def __str__(self):
        '''Return a string representaion of this object.'''
        return '%s %s %s' % (self.timestamp, self.message, self.image)